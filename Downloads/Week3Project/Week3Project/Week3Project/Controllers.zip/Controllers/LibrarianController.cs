﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Web.Mvc;
using Week3Project.Models;

namespace Week3Project.Controllers
{
    public class LibrarianController : Controller
    {
        public List<PublicationModel> publications = new List<PublicationModel>();
        public List<StudentLoginModel> students = new List<StudentLoginModel>();
        public List<BookModel> books = new List<BookModel>();
        public List<BranchModel> branches = new List<BranchModel>();
        public List<IssueDateModel> issueDate = new List<IssueDateModel>();
        public List<ReturnDateModel> returnDates = new List<ReturnDateModel>();
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult AddPublication()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddPublication(PublicationModel publication)
        {
            if (ModelState.IsValid)
            {
                publication.PublicationId = publications.Count + 1;
                publications.Add(publication);
                DashBoard viewModel = new DashBoard
                {
                    Publications = publications,
                };
                return View("DashBoard", viewModel);
            }

            return View("AddPublication", publication);
        }
        [HttpGet]
        public ActionResult AddStudent()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddStudent(StudentLoginModel student)
        {
            if (ModelState.IsValid)
            {
                student.StudentId = students.Count + 1;
                students.Add(student);
                DashBoard ViewModel = new DashBoard
                {
                    Students = students,
                };
                return View("DashBoard", ViewModel);
            }
            return View("AddStudent", student);
        }
        [HttpGet]
        public ActionResult AddStock()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddStock(BookModel book)
        {
            if (ModelState.IsValid)
            {
                book.BookId = books.Count + 1;
                books.Add(book);
                DashBoard ViewModel = new DashBoard
                {
                    Books = books,
                };
                return View("DashBoard", ViewModel);
            }
            return View("AddStock", book);
        }
        [HttpGet]
        public ActionResult AddBranch()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddBranch(BranchModel branch)
        {
            if (ModelState.IsValid)
            {
                branches.Add(branch);
                DashBoard ViewModel = new DashBoard
                {
                    Branches = branches,
                };
                return View("DashBoard", ViewModel);
            }
            return View("AddBranches", branch);
        }
        [HttpGet]
        public ActionResult IssueDate()
        {
            return View();
        }
        [HttpPost]
        public ActionResult IssueDate(IssueDateModel issue)
        {
            if (ModelState.IsValid)
            {
                DashBoard ViewModel = new DashBoard
                {
                    IssueDates = issueDate,
                };
                
                return View("DashBoard",ViewModel);
            }
            return View("IssueDate", issue);
        }
        public ActionResult ReturnDate()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ReturnDate(ReturnDateModel returnDate)
        {
            if (ModelState.IsValid)
            {
                returnDates.Add(returnDate);
                DashBoard viewModel = new DashBoard
                {
                    ReturnDates = returnDates
                };

                TempData["SuccessMessage"] = "Return date added successfully.";
                return View("DashBoard", viewModel);
            }

            return View(returnDate);
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult LibraryLogin(LibrarionLoginModel login)
        {
            List<string> validUsernames = new List<string> { "Library", "AnotherUser", };
            List<string> validPasswords = new List<string> { "LibraryPassword", "AnotherPassword", };
            if (validUsernames.Contains(login.Username) && validPasswords.Contains(login.Password))
            {
                return RedirectToAction("DashBoard");
            }
            else
            {
                ViewBag.ErrorMessage = "Invalid username or password.";
                return View("LibraryLogin", login);
            }
        }
        public ActionResult DashBoard()
        {
            DashBoard viewModel = new DashBoard
            {
                Publications = publications,
                Students = students,
                Books = books,
                Branches = branches,
                IssueDates = issueDate,
                ReturnDates = returnDates
            };
            return View(viewModel);
        }
        [HttpPost]
        public ActionResult DashBoard(DashBoard dashBoard)
        {
            return View("DashBoard", dashBoard);
        }
    }
}