﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Week3Project.Models;

namespace Week3Project.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            return View();
            
        }
        public ActionResult StudentLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult StudentLogin(StudentLoginModel login)
        {
            if (login.Username == "student" && login.Password == "studentpassword")
            {
                return RedirectToAction("StudentDashBoard");
            }
            ViewBag.ErrorMessage = "Invalid username or password.";
            return View("StudentLogin", login);
        }


        public ActionResult StudentDashBoard(StudentDashBoard studentdashboard)
        {
            return View("StudentDashBoard",studentdashboard);
        }

        public ActionResult StudentReport()
        {
            var studentReportData = new StudentReportModel
            {
                Id = 1,
                Name = "Nikshay khandelwal",
                Description = "He takes 10 Books",
                Username = "student",
                Password = "studentPassword",


            };

            return View(studentReportData);
        }


    }
}